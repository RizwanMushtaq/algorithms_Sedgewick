public class HalloWorld {
  public static void main(String[] args) {
    System.out.println("Hallo, World!");
  }
}